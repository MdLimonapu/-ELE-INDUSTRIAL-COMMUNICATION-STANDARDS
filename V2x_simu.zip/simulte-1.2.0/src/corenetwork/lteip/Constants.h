#ifndef _LTE_LTEIP_CONSTANTS_H_
#define _LTE_LTEIP_CONSTANTS_H_
namespace inet {
    const int UDP_HEADER_BYTES = 8;
}

#endif
